import time
from collections.abc import Callable
from typing import Any

import httpx
import pytest

from free_claude_code.application.routing import ModelRouter
from free_claude_code.config.reasoning import ReasoningPreference
from free_claude_code.core.anthropic.stream_contracts import (
    SSEEvent,
    parse_sse_lines,
)
from free_claude_code.core.history_replay import decode_replay, is_replay
from smoke.lib.config import ProviderModel, SmokeConfig
from smoke.lib.e2e import (
    ConversationDriver,
    ProviderMatrixDriver,
    SmokeServerDriver,
    assert_native_thinking_stream,
    assert_product_stream,
    echo_tool_schema,
    tool_use_blocks,
)
from smoke.lib.http import collect_message_stream, conversation_headers
from smoke.lib.server import RunningServer
from smoke.lib.skips import (
    skip_if_upstream_unavailable_events,
    skip_if_upstream_unavailable_exception,
)
from tests.wire_payload import object_array, object_payload, response_object

pytestmark = [pytest.mark.live, pytest.mark.smoke_target("providers")]


def test_provider_matrix_presence_e2e(smoke_config: SmokeConfig) -> None:
    models = ProviderMatrixDriver(smoke_config).provider_smoke_models()
    assert models or smoke_config.provider_matrix == frozenset()


def test_model_mapping_matrix_e2e(smoke_config: SmokeConfig) -> None:
    models = ProviderMatrixDriver(smoke_config).configured_models()
    sources = {model.source for model in models}
    assert sources <= {
        "MODEL",
        "MODEL_FABLE",
        "MODEL_OPUS",
        "MODEL_SONNET",
        "MODEL_HAIKU",
    }
    for model in models:
        assert model.provider
        assert model.model_name


def test_provider_text_multiturn_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    _run_provider_scenario(smoke_config, provider_model, _scenario_text_multiturn)


def test_provider_adaptive_thinking_history_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    _run_provider_scenario(
        smoke_config, provider_model, _scenario_adaptive_thinking_history
    )


def test_provider_interleaved_thinking_tool_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    if provider_model.provider == "gemini":
        pytest.skip("synthetic tool history cannot carry native Gemini signatures")
    _run_provider_scenario(smoke_config, provider_model, _scenario_interleaved_history)


@pytest.mark.smoke_target("tools")
def test_provider_tool_use_then_text_history_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    """OpenAI-compatible path: history with tool_use + assistant text after tool (issue #206)."""
    if provider_model.provider == "gemini":
        pytest.skip(
            "synthetic post-tool narration cannot carry native Gemini signatures"
        )
    _run_provider_scenario(
        smoke_config, provider_model, _scenario_tool_use_then_text_in_history
    )


@pytest.mark.smoke_target("tools")
def test_provider_tool_result_continuation_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    _run_provider_scenario(
        smoke_config, provider_model, _scenario_tool_result_continuation
    )


@pytest.mark.smoke_target("tools")
def test_provider_tool_history_resume_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    _run_provider_scenario(smoke_config, provider_model, _scenario_tool_history_resume)


@pytest.mark.smoke_target("tools")
def test_gemini_thought_signature_tool_continuation_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    if provider_model.provider != "gemini":
        pytest.skip("gemini-specific smoke scenario")
    _run_provider_scenario(
        smoke_config,
        provider_model,
        _scenario_gemini_thought_signature_tool_continuation,
    )


@pytest.mark.smoke_target("tools")
def test_provider_reasoning_tool_continuation_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    if not _provider_smoke_reasoning_enabled(smoke_config):
        pytest.skip("the configured Claude route disables reasoning")
    _run_provider_scenario(
        smoke_config, provider_model, _scenario_reasoning_tool_continuation
    )


def test_mistral_native_reasoning_model_e2e(smoke_config: SmokeConfig) -> None:
    provider_model = smoke_config.mistral_reasoning_smoke_model()
    if provider_model is None:
        pytest.skip("missing_env: mistral is not configured")

    payload = {
        "model": "claude-opus-4-7",
        "max_tokens": 4096,
        "messages": [{"role": "user", "content": "Reply with one short sentence."}],
        "thinking": {"type": "adaptive"},
    }
    try:
        with _server_for_provider(
            smoke_config, provider_model, "mistral-native-reasoning"
        ) as server:
            events = collect_message_stream(server, payload, smoke_config)
    except Exception as exc:
        skip_if_upstream_unavailable_exception(exc)
        raise

    assert_native_thinking_stream(
        events,
        context=f"{provider_model.source}={provider_model.full_model}",
    )


def test_mistral_prompt_cache_affinity_e2e(smoke_config: SmokeConfig) -> None:
    """Mistral prompt caching via the x-affinity session header (merge gate).

    The x-affinity mechanism is reverse-engineered from the official Mistral
    CLI (mistral-vibe), not a public API contract. Two requests sharing one
    session id and a long common prefix must report cache reads on the second
    response. Cache support is model-dependent and best-effort, so the gate
    pins a model that consistently reports cache reads and retries the
    follow-up with escalating pauses (the cache is eventually consistent).
    """
    provider_model = smoke_config.mistral_cache_smoke_model()
    if provider_model is None:
        pytest.skip("missing_env: mistral is not configured")

    headers = conversation_headers(session_id="fcc-smoke-mistral-cache-affinity")
    first_payload = {
        # fcc-smoke-default routes to the MODEL override (the Mistral model);
        # tier names like claude-opus-4-7 would route to MODEL_OPUS instead.
        "model": "fcc-smoke-default",
        "max_tokens": 256,
        "system": _long_cacheable_system_prompt(),
        "messages": [{"role": "user", "content": "Say hello in one word."}],
    }
    second_payload = {
        **first_payload,
        "messages": [
            first_payload["messages"][0],
            {"role": "user", "content": "Now say goodbye in one word."},
        ],
    }

    try:
        with SmokeServerDriver(
            smoke_config,
            name="product-provider-mistral-prompt-cache-affinity",
            env_overrides={
                "MODEL": provider_model.full_model,
                "MODEL_FALLBACKS": "",
                "MESSAGING_PLATFORM": "none",
            },
        ).run() as server:
            cached_reads = _mistral_cached_reads_with_retry(
                server, smoke_config, headers, first_payload, second_payload
            )
    except Exception as exc:
        skip_if_upstream_unavailable_exception(exc)
        raise

    assert cached_reads > 0, (
        f"{provider_model.source}={provider_model.full_model}: "
        "no prompt cache reads reported on the second request"
    )


@pytest.mark.smoke_target("rate_limit")
def test_provider_disconnect_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    _run_provider_scenario(smoke_config, provider_model, _scenario_disconnect)


def test_provider_error_e2e(smoke_config: SmokeConfig) -> None:
    provider_model = ProviderMatrixDriver(smoke_config).first_model()
    broken_model = f"{provider_model.provider}/fcc-smoke-missing-model"
    with (
        SmokeServerDriver(
            smoke_config,
            name=f"product-provider-error-{provider_model.provider}",
            env_overrides={"MODEL": broken_model, "MESSAGING_PLATFORM": "none"},
        ).run() as server,
        httpx.Client(timeout=smoke_config.timeout_s) as client,
    ):
        response = client.post(
            f"{server.base_url}/v1/messages",
            headers=conversation_headers(),
            json={
                "model": "fcc-smoke-default",
                "max_tokens": 32,
                "messages": [{"role": "user", "content": "hello"}],
            },
        )

    assert response.status_code >= 400
    assert response.headers["content-type"].startswith("application/json")
    assert response.headers["x-should-retry"] == "false"
    payload = response_object(response)
    assert payload["type"] == "error"
    assert object_payload(payload["error"])["type"]
    assert object_payload(payload["error"])["message"]
    assert payload["request_id"] == response.headers["request-id"]


def test_provider_codex_responses_text_e2e(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    try:
        with (
            _server_for_provider(
                smoke_config, provider_model, "codex-responses"
            ) as server,
            httpx.stream(
                "POST",
                f"{server.base_url}/v1/responses",
                headers=_openai_auth_headers(smoke_config),
                json={
                    "model": provider_model.full_model,
                    "input": smoke_config.prompt,
                    "max_output_tokens": 1024,
                    "stream": True,
                },
                timeout=smoke_config.timeout_s,
            ) as response,
        ):
            assert response.status_code == 200, response.read()
            events = parse_sse_lines(response.iter_lines())
    except Exception as exc:
        skip_if_upstream_unavailable_exception(exc)
        raise

    skip_if_upstream_unavailable_events(events)
    names = [event.event for event in events]
    assert names[0] == "response.created", names
    assert names[-1] == "response.completed", names
    assert any(event.event == "response.output_text.delta" for event in events), names


def test_openrouter_native_e2e(smoke_config: SmokeConfig) -> None:
    models = [
        model
        for model in ProviderMatrixDriver(smoke_config).provider_smoke_models()
        if model.provider == "open_router"
    ]
    if not models:
        pytest.skip("missing_env: open_router is not configured")

    provider_model = models[0]
    with SmokeServerDriver(
        smoke_config,
        name="product-openrouter-native",
        env_overrides={
            "MODEL": provider_model.full_model,
            "MESSAGING_PLATFORM": "none",
        },
    ).run() as server:
        turn = ConversationDriver(server, smoke_config).stream(
            {
                "model": "claude-opus-4-7",
                "max_tokens": 256,
                "messages": [
                    {
                        "role": "user",
                        "content": "Reply with one short sentence.",
                    }
                ],
                "thinking": {"type": "adaptive", "budget_tokens": 1024},
            }
        )
    _assert_provider_product_stream(turn.events)


def _run_provider_scenario(
    smoke_config: SmokeConfig,
    provider_model: ProviderModel,
    scenario: Callable[[SmokeConfig, ProviderModel], None],
) -> None:
    try:
        scenario(smoke_config, provider_model)
    except Exception as exc:
        skip_if_upstream_unavailable_exception(exc)
        raise AssertionError(
            f"{provider_model.source}={provider_model.full_model}: "
            f"{type(exc).__name__}: {exc}"
        ) from exc


def _assert_provider_product_stream(events: list[SSEEvent]) -> None:
    skip_if_upstream_unavailable_events(events)
    assert_product_stream(events)


def _tool_use_blocks_or_skip(
    events: list[SSEEvent], message: str
) -> list[dict[str, Any]]:
    skip_if_upstream_unavailable_events(events)
    blocks = tool_use_blocks(events)
    assert blocks, message
    return blocks


def _provider_smoke_reasoning_enabled(smoke_config: SmokeConfig) -> bool:
    return (
        ModelRouter(smoke_config.settings)
        .resolve("claude-sonnet-4-5-20250929")
        .reasoning_preference
        is not ReasoningPreference.OFF
    )


def _scenario_text_multiturn(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    with _server_for_provider(smoke_config, provider_model, "text") as server:
        driver = ConversationDriver(server, smoke_config)
        first = driver.ask("Reply with one short sentence.", max_tokens=4096)
        second = driver.ask("Reply with a different short sentence.", max_tokens=4096)
    _assert_provider_product_stream(first.events)
    _assert_provider_product_stream(second.events)


def _scenario_adaptive_thinking_history(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    payload = {
        "model": "claude-opus-4-7",
        "max_tokens": 2048,
        "messages": [{"role": "user", "content": "Reply with one short sentence."}],
        "thinking": {"type": "adaptive", "budget_tokens": 1024},
    }
    with _server_for_provider(smoke_config, provider_model, "adaptive") as server:
        driver = ConversationDriver(server, smoke_config)
        first = driver.stream(payload)
        second = driver.stream(
            {
                **payload,
                "messages": [
                    *payload["messages"],
                    {"role": "assistant", "content": first.assistant_content},
                    {
                        "role": "user",
                        "content": "Reply with a different short sentence.",
                    },
                ],
            }
        )
    _assert_provider_product_stream(first.events)
    _assert_provider_product_stream(second.events)


def _scenario_interleaved_history(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 1024,
        "messages": [
            {"role": "user", "content": "Use the tool."},
            {
                "role": "assistant",
                "content": [
                    {"type": "thinking", "thinking": "Need to inspect first."},
                    {"type": "text", "text": "I will call the tool."},
                    {
                        "type": "tool_use",
                        "id": "toolu_interleaved",
                        "name": "echo_smoke",
                        "input": {"value": "FCC_INTERLEAVED"},
                    },
                ],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "toolu_interleaved",
                        "content": "FCC_INTERLEAVED",
                    }
                ],
            },
        ],
        "tools": [echo_tool_schema()],
        "thinking": {"type": "adaptive"},
    }
    with _server_for_provider(smoke_config, provider_model, "interleaved") as server:
        turn = ConversationDriver(server, smoke_config).stream(payload)
    _assert_provider_product_stream(turn.events)


def _scenario_tool_use_then_text_in_history(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    tool_id = "toolu_206_smoke"
    payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 256,
        "messages": [
            {"role": "user", "content": "We will use echo_smoke once in this session."},
            {
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "id": tool_id,
                        "name": "echo_smoke",
                        "input": {"value": "FCC_206_SMOKE"},
                    },
                    {
                        "type": "text",
                        "text": "Narration after the tool call (issue #206 shape).",
                    },
                ],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": "FCC_206_SMOKE",
                    },
                ],
            },
            {
                "role": "user",
                "content": "Reply in one short sentence: did you see the echo value?",
            },
        ],
        "tools": [echo_tool_schema()],
    }
    with _server_for_provider(smoke_config, provider_model, "tool-206") as server:
        turn = ConversationDriver(server, smoke_config).stream(payload)
    _assert_provider_product_stream(turn.events)


def _scenario_tool_result_continuation(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    first_payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 256,
        "messages": [
            {"role": "user", "content": "Use echo_smoke once with value FCC_TOOL."}
        ],
        "tools": [echo_tool_schema()],
        "tool_choice": {"type": "tool", "name": "echo_smoke"},
        "thinking": {"type": "adaptive"},
    }
    with _server_for_provider(smoke_config, provider_model, "tool") as server:
        driver = ConversationDriver(server, smoke_config)
        first = driver.stream(first_payload)
        tool_uses = _tool_use_blocks_or_skip(
            first.events, "provider did not emit a tool_use block"
        )
        tool_use = tool_uses[0]
        second_payload = {
            "model": "claude-sonnet-4-5-20250929",
            "max_tokens": 256,
            "messages": [
                first_payload["messages"][0],
                {"role": "assistant", "content": first.assistant_content},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_use["id"],
                            "content": "FCC_TOOL",
                        }
                    ],
                },
            ],
            "tools": [echo_tool_schema()],
        }
        second = driver.stream(second_payload)
    _assert_provider_product_stream(first.events)
    _assert_provider_product_stream(second.events)


def _scenario_tool_history_resume(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    first_payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 256,
        "messages": [
            {"role": "user", "content": "Use echo_smoke with value FCC_RESUME."}
        ],
        "tools": [echo_tool_schema()],
        "tool_choice": {"type": "tool", "name": "echo_smoke"},
        "thinking": {"type": "adaptive"},
    }
    with _server_for_provider(
        smoke_config, provider_model, "tool-history-resume"
    ) as server:
        driver = ConversationDriver(server, smoke_config)
        first = driver.stream(first_payload)
        tool_use = _tool_use_blocks_or_skip(
            first.events, "provider did not emit a tool_use block"
        )[0]
        second = driver.stream(
            {
                "model": first_payload["model"],
                "max_tokens": 256,
                "messages": [
                    *first_payload["messages"],
                    {"role": "assistant", "content": first.assistant_content},
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": tool_use["id"],
                                "content": "FCC_RESUME",
                            }
                        ],
                    },
                    {
                        "role": "user",
                        "content": "Reply exactly OK without calling tools.",
                    },
                ],
                "tools": first_payload["tools"],
            }
        )
    _assert_provider_product_stream(first.events)
    _assert_provider_product_stream(second.events)


def _scenario_gemini_thought_signature_tool_continuation(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    first_payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 256,
        "messages": [
            {"role": "user", "content": "Use echo_smoke once with value FCC_TOOL."}
        ],
        "tools": [echo_tool_schema()],
        "tool_choice": {"type": "tool", "name": "echo_smoke"},
        "thinking": {"type": "adaptive", "budget_tokens": 1024},
    }
    with _server_for_provider(
        smoke_config, provider_model, "gemini-signature"
    ) as server:
        driver = ConversationDriver(server, smoke_config)
        first = driver.stream(first_payload)
        tool_uses = _tool_use_blocks_or_skip(
            first.events, "gemini did not emit a tool_use block"
        )
        tool_use = tool_uses[0]
        records = [
            decode_replay(block["data"])
            for block in first.assistant_content
            if block.get("type") == "redacted_thinking" and is_replay(block.get("data"))
        ]
        assert any(
            part.get("thoughtSignature")
            for record in records
            for part in object_array(record.native.get("parts", []))
        ), "gemini tool turn did not preserve its native thought signature"
        second_payload = {
            "model": "claude-sonnet-4-5-20250929",
            "max_tokens": 256,
            "messages": [
                first_payload["messages"][0],
                {"role": "assistant", "content": first.assistant_content},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": tool_use["id"],
                            "content": "FCC_TOOL",
                        }
                    ],
                },
            ],
            "tools": [echo_tool_schema()],
            "thinking": {"type": "adaptive", "budget_tokens": 1024},
        }
        second = driver.stream(second_payload)
    _assert_provider_product_stream(first.events)
    _assert_provider_product_stream(second.events)


def _scenario_reasoning_tool_continuation(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    payload = {
        "model": "claude-sonnet-4-5-20250929",
        "max_tokens": 256,
        "messages": [
            {"role": "user", "content": "Use echo_smoke once with value FCC_TOOL."},
            {
                "role": "assistant",
                "content": [
                    {"type": "thinking", "thinking": "Need to return the echo result."},
                    {
                        "type": "tool_use",
                        "id": "toolu_reasoning_smoke",
                        "name": "echo_smoke",
                        "input": {"value": "FCC_TOOL"},
                    },
                ],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "toolu_reasoning_smoke",
                        "content": "FCC_TOOL",
                    }
                ],
            },
        ],
        "tools": [echo_tool_schema()],
        "thinking": {"type": "adaptive"},
    }
    with _server_for_provider(smoke_config, provider_model, "reasoning-tool") as server:
        turn = ConversationDriver(server, smoke_config).stream(payload)
    _assert_provider_product_stream(turn.events)


def _scenario_disconnect(
    smoke_config: SmokeConfig, provider_model: ProviderModel
) -> None:
    headers = conversation_headers()
    with _server_for_provider(smoke_config, provider_model, "disconnect") as server:
        with httpx.stream(
            "POST",
            f"{server.base_url}/v1/messages",
            headers=headers,
            json={
                "model": "fcc-smoke-default",
                "max_tokens": 512,
                "messages": [{"role": "user", "content": smoke_config.prompt}],
            },
            timeout=smoke_config.timeout_s,
        ) as response:
            assert response.status_code == 200, response.read()
            for _line in response.iter_lines():
                break
        health = httpx.get(f"{server.base_url}/health", timeout=5)
        assert health.status_code == 200
        followup = ConversationDriver(server, smoke_config).ask(
            "Reply with one short sentence.", max_tokens=4096, headers=headers
        )
    _assert_provider_product_stream(followup.events)


def _server_for_provider(
    smoke_config: SmokeConfig, provider_model: ProviderModel, name: str
):
    return SmokeServerDriver(
        smoke_config,
        name=f"product-provider-{provider_model.provider}-{name}",
        env_overrides={
            "MODEL": provider_model.full_model,
            "MESSAGING_PLATFORM": "none",
            "MODEL_FALLBACKS": "",
            "REASONING_POLICY": "client",
            **{f"MODEL_{tier}": "" for tier in ("FABLE", "OPUS", "SONNET", "HAIKU")},
            **{
                f"REASONING_{tier}": "inherit"
                for tier in ("FABLE", "OPUS", "SONNET", "HAIKU")
            },
        },
    ).run()


def _openai_auth_headers(smoke_config: SmokeConfig) -> dict[str, str]:
    headers = {"content-type": "application/json"}
    token = smoke_config.settings.proxy_auth_token
    if token:
        headers["authorization"] = f"Bearer {token}"
    return conversation_headers(headers)


def _long_cacheable_system_prompt() -> str:
    """Build a deterministic system prompt far above the minimum cacheable prefix."""
    paragraph = (
        "You are a concise assistant in a long-running support conversation. "
        "Answer every question with a single short sentence and nothing else. "
    )
    return paragraph * 40


def _mistral_cached_reads_with_retry(
    server: RunningServer,
    smoke_config: SmokeConfig,
    headers: dict[str, str],
    first_payload: dict[str, Any],
    second_payload: dict[str, Any],
    *,
    read_pauses_s: tuple[float, ...] = (3, 3, 5, 8, 13, 21),
) -> int:
    """Warm the cache, then return follow-up cache reads, retrying misses.

    Mistral prompt caching is best-effort and eventually consistent: the
    warm request's cache write becomes visible to later requests only after
    a variable delay (observed from ~3s to ~25s). The first probe matches the
    observed minimum propagation (~3s); later pauses escalate, so the probes
    land at ~3, 6, 11, 19, 32, and 53s after the warm request and the final
    probe covers the observed upper bound with margin.
    """
    warm_events = collect_message_stream(
        server, first_payload, smoke_config, headers=headers
    )
    skip_if_upstream_unavailable_events(warm_events)
    for pause_s in read_pauses_s:
        time.sleep(pause_s)
        followup_events = collect_message_stream(
            server, second_payload, smoke_config, headers=headers
        )
        skip_if_upstream_unavailable_events(followup_events)
        cached_reads = _cache_read_input_tokens(followup_events)
        if cached_reads > 0:
            return cached_reads
    return 0


def _cache_read_input_tokens(events: list[SSEEvent]) -> int:
    for event in events:
        if event.event != "message_delta":
            continue
        usage = event.data.get("usage")
        if isinstance(usage, dict):
            cached = usage.get("cache_read_input_tokens")
            if isinstance(cached, int) and not isinstance(cached, bool):
                return cached
    return 0
