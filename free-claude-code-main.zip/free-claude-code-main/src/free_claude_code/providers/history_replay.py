"""Provider connection provenance and precise historical request corrections."""

import hashlib
import re
from collections.abc import Iterator, Mapping
from copy import deepcopy
from typing import TYPE_CHECKING
from urllib.parse import urlsplit, urlunsplit

from free_claude_code.application.errors import InvalidRequestError
from free_claude_code.core.anthropic.models import Message, MessagesRequest
from free_claude_code.core.diagnostics import extract_upstream_error_detail
from free_claude_code.core.history_replay import (
    HistoryPath,
    HistoryProtocol,
    HistoryReplayError,
    ReplayOrigin,
    ReplayRecord,
    decode_replay,
    encode_replay,
    is_replay,
    normalize_history_source,
    protected_reasoning,
    readable_reasoning,
    resolve_messages_replay,
)
from free_claude_code.core.json_types import (
    JsonObject,
    JsonValue,
    json_array,
    json_index,
    json_object,
    load_json_value,
)

from .endpoint_types import HttpEndpoint

if TYPE_CHECKING:
    from openai import AsyncOpenAI


def validate_history(body: Mapping[str, JsonValue]) -> None:
    """Reject malformed persisted carriers before credentials or inference."""
    try:
        for protocol in ("responses", "messages", "chat"):
            for _, item in _reasoning_records(body, protocol):
                for key in ("encrypted_content", "signature", "data"):
                    value = item.get(key)
                    if isinstance(value, str) and is_replay(value):
                        decode_replay(value)
    except HistoryReplayError as error:
        raise InvalidRequestError(str(error)) from error


def normalize_messages_history(request: MessagesRequest) -> MessagesRequest:
    """Resolve persisted associations before any lossy protocol conversion."""
    validate_history(request.model_dump(mode="json"))
    messages = []
    try:
        for message in request.messages:
            if message.role != "assistant":
                messages.append(message)
                continue
            body: JsonObject = message.model_dump(mode="json")
            blocks = body["content"]
            if isinstance(blocks, list):
                blocks = resolve_messages_replay(blocks)
            if message.reasoning_content is not None:
                if isinstance(blocks, str):
                    blocks = [{"type": "text", "text": blocks}] if blocks else []
                full: list[str] = []
                blocks = json_array(blocks)
                for block in blocks:
                    if not isinstance(block, dict):
                        continue
                    native = block
                    carrier = block.get("signature", block.get("data"))
                    if isinstance(carrier, str) and is_replay(carrier):
                        native = decode_replay(carrier).native
                    full.extend(
                        text
                        for text, summary in readable_reasoning(native)
                        if not summary
                    )
                represented = set(full)
                if full:
                    represented.update(
                        separator.join(full) for separator in ("", "\n", "\n\n")
                    )
                if message.reasoning_content not in represented:
                    blocks.insert(
                        0, {"type": "thinking", "thinking": message.reasoning_content}
                    )
                body["reasoning_content"] = None
            body["content"] = blocks
            normalized = normalize_history_source({"messages": [body]}, "messages")
            messages.append(
                Message.model_validate(json_array(normalized["messages"])[0])
            )
    except HistoryReplayError as error:
        raise InvalidRequestError(str(error)) from error
    return request.model_copy(update={"messages": messages})


def replay_origin(
    provider: str,
    protocol: HistoryProtocol,
    model: str,
    *,
    client: AsyncOpenAI | None = None,
    endpoint: HttpEndpoint | None = None,
) -> ReplayOrigin:
    """Identify the actual connection without storing its credentials."""
    base_url = (
        endpoint.base_url
        if endpoint is not None
        else str(client.base_url)
        if client is not None
        else ""
    )
    headers: Mapping[str, object] = (
        endpoint.headers
        if endpoint is not None
        else client.default_headers
        if client is not None
        else {}
    )
    normalized_headers = {
        key.lower(): value for key, value in headers.items() if isinstance(value, str)
    }
    key = (
        endpoint.api_key
        if endpoint is not None
        else client.api_key
        if client is not None
        else None
    )
    account = endpoint.account_id if endpoint is not None else None
    credential = (
        "account:" + account
        if account
        else "key:" + key
        if isinstance(key, str) and key
        else "auth:"
        + normalized_headers.get(
            "authorization", normalized_headers.get("x-api-key", "")
        )
    )
    parsed = urlsplit(base_url)
    host = parsed.hostname or ""
    if ":" in host:
        host = f"[{host}]"
    if parsed.port:
        host += f":{parsed.port}"
    address = urlunsplit((parsed.scheme, host, parsed.path.rstrip("/"), "", ""))
    return ReplayOrigin(
        provider,
        protocol,
        address,
        hashlib.sha256(credential.encode()).hexdigest(),
        model,
    )


def history_retry_body(
    error: Exception,
    body: Mapping[str, JsonValue],
    protocol: HistoryProtocol,
    *,
    source: Mapping[str, JsonValue] | None = None,
    source_paths: Mapping[HistoryPath, HistoryPath] | None = None,
) -> JsonObject | None:
    """Repair one explicitly rejected historical record on an independent copy."""
    body = normalize_history_source(body, protocol)
    if source is not None:
        source = normalize_history_source(source, protocol)
    detail = extract_upstream_error_detail(error)
    if detail.status_code not in {None, 200, 400, 422}:
        return None
    try:
        payload = load_json_value(detail.body_text or "")
    except ValueError:
        payload = {
            "message": detail.exception_text or str(error),
            "code": code
            if isinstance(code := getattr(error, "code", None), str)
            else None,
        }
    candidates = list(_reasoning_records(body, protocol))
    for record in _error_records(payload):
        message = str(record.get("message", ""))
        code = record.get("code", record.get("type"))
        invalid_id = bool(
            re.search(
                r"invalid.+(?:input|messages).+\.id.+(?:letters|characters|ID)",
                message,
                re.I,
            )
        )
        invalid_native = code in (
            "invalid_encrypted_content",
            "invalid_signature",
        ) or bool(
            re.search(
                r"invalid signature in thinking block|referenced reasoning item .+ (?:not found|expired)",
                message,
                re.I,
            )
        )
        if not (invalid_id or invalid_native):
            continue
        matched = _rejected_record(record, candidates)
        if matched is None:
            continue
        path, original = matched
        if invalid_native and not protected_reasoning(original):
            # A readable-only rejection belongs to mode negotiation, not opaque
            # state repair. In particular, never turn partial thinking into prose.
            continue
        if source is not None:
            mapped = source_paths.get(path) if source_paths is not None else None
            if mapped is None:
                continue
            path = mapped
        result: JsonObject = deepcopy(dict(source if source is not None else body))
        parent: JsonValue = result
        for key in path[:-1]:
            parent = _history_child(parent, key)
        source_parent = parent
        source_key = path[-1]
        target_key = source_key
        replay = None
        carrier_key = None
        holder: JsonObject | None = None
        stored = _history_child(parent, source_key)
        if isinstance(stored, dict):
            for field in ("data", "signature", "encrypted_content"):
                carrier = stored.get(field)
                if isinstance(carrier, str) and is_replay(carrier):
                    candidate = decode_replay(carrier)
                    native = deepcopy(candidate.native)
                    details = native.get("reasoning_details")
                    if (
                        protocol == "chat"
                        and isinstance(details, list)
                        and original in details
                    ):
                        replay, carrier_key, holder = candidate, field, native
                        parent, target_key = details, details.index(original)
                    elif native == original:
                        replay, carrier_key = candidate, field
                        holder = {"item": native}
                        parent, target_key = holder, "item"
                    break
        if invalid_id:
            value = original.get("id")
            if not isinstance(value, str) or re.fullmatch(r"[A-Za-z0-9_-]+", value):
                continue
            corrected = "rs_" + hashlib.sha256(value.encode()).hexdigest()[:24]
            json_object(_history_child(parent, target_key))["id"] = corrected
            for item in json_array(result.get("input", [])):
                if (
                    isinstance(item, dict)
                    and item.get("type") == "item_reference"
                    and item.get("id") == value
                ):
                    item["id"] = corrected
        else:
            context = "\n\n".join(
                text
                for text, _ in readable_reasoning(
                    original
                    if protocol != "chat"
                    else {"reasoning_details": [original]}
                )
            )
            if protocol == "responses" and context:
                _replace_history_child(
                    parent, target_key, {"role": "assistant", "content": context}
                )
            elif protocol == "messages" and context:
                _replace_history_child(
                    parent, target_key, {"type": "text", "text": context}
                )
            else:
                _delete_history_child(parent, target_key)
                if protocol == "chat":
                    assistant = json_object(
                        json_array(result["messages"])[json_index(path[1])]
                    )
                    if context:
                        content = assistant.get("content") or ""
                        if not isinstance(content, str):
                            raise TypeError("Expected text in Chat reasoning history")
                        assistant["content"] = content + "\n\n" + context
                    if not parent and replay is None:
                        assistant.pop("reasoning_details", None)
        if (
            replay is not None
            and holder is not None
            and carrier_key is not None
            and isinstance(stored, dict)
        ):
            if target_key == "item":
                replacement = holder.get("item")
                if replacement is None:
                    _delete_history_child(source_parent, source_key)
                elif invalid_id:
                    stored[carrier_key] = encode_replay(
                        ReplayRecord(replay.origin, json_object(replacement))
                    )
                else:
                    _replace_history_child(source_parent, source_key, replacement)
            else:
                stored[carrier_key] = encode_replay(ReplayRecord(replay.origin, holder))
        return result
    return None


def _history_child(parent: JsonValue, key: str | int) -> JsonValue:
    if isinstance(key, int):
        return json_array(parent)[key]
    return json_object(parent)[key]


def _replace_history_child(parent: JsonValue, key: str | int, value: JsonValue) -> None:
    if isinstance(key, int):
        json_array(parent)[key] = value
    else:
        json_object(parent)[key] = value


def _delete_history_child(parent: JsonValue, key: str | int) -> None:
    if isinstance(key, int):
        del json_array(parent)[key]
    else:
        del json_object(parent)[key]


def _reasoning_records(
    body: Mapping[str, JsonValue], protocol: HistoryProtocol
) -> Iterator[tuple[tuple[str | int, ...], Mapping[str, JsonValue]]]:
    if protocol == "responses":
        items = body.get("input")
        if isinstance(items, Mapping):
            items = [items]
        for index, item in enumerate(items if isinstance(items, list) else []):
            if isinstance(item, Mapping) and item.get("type") == "reasoning":
                yield ("input", index), item
        return
    for index, message in enumerate(json_array(body.get("messages", []))):
        if not isinstance(message, Mapping) or message.get("role") != "assistant":
            continue
        field = "content" if protocol == "messages" else "reasoning_details"
        blocks = message.get(field)
        if not isinstance(blocks, list):
            continue
        for block_index, block in enumerate(blocks):
            if isinstance(block, Mapping) and (
                protocol == "chat"
                or block.get("type") in ("thinking", "redacted_thinking")
            ):
                yield ("messages", index, field, block_index), block


def _error_records(payload: JsonValue) -> Iterator[Mapping[str, JsonValue]]:
    if isinstance(payload, Mapping):
        if isinstance(payload.get("message"), str):
            yield payload
        for key in ("error", "errors", "metadata", "raw", "previous_errors"):
            nested = payload.get(key)
            if key == "raw" and isinstance(nested, str):
                try:
                    nested = load_json_value(nested)
                except ValueError:
                    continue
            yield from _error_records(nested)
    elif isinstance(payload, list):
        for item in payload:
            yield from _error_records(item)


def _rejected_record(
    error: Mapping[str, JsonValue],
    candidates: list[tuple[tuple[str | int, ...], Mapping[str, JsonValue]]],
) -> tuple[tuple[str | int, ...], Mapping[str, JsonValue]] | None:
    location = str(error.get("param") or error.get("loc") or error.get("message") or "")
    match = re.search(
        r"(?:input|messages)(?:\[\d+\]|\.\d+)(?:(?:\.content|\.reasoning_details)(?:\[\d+\]|\.\d+))?",
        location,
    )
    if match:
        path = tuple(
            int(part) if part.isdigit() else part
            for part in (token[0] for token in re.finditer(r"[a-z_]+|\d+", match[0]))
        )
        return next((entry for entry in candidates if entry[0] == path), None)
    message = str(error.get("message", ""))
    named_ids = {
        value
        for match in re.finditer(
            r"\b(?:for item|reasoning item|and item)\s+"
            r"(?:'([^']+)'|\"([^\"]+)\"|([A-Za-z0-9_-]+))(?=\s|[.,:]|$)",
            message,
            re.I,
        )
        for value in match.groups()
        if value
    }
    identified = [
        entry
        for entry in candidates
        if isinstance(item_id := entry[1].get("id"), str)
        and (
            item_id in named_ids
            or f"'{entry[1]['id']}'" in message
            or f'"{entry[1]["id"]}"' in message
        )
    ]
    if len(identified) == 1 and (
        not named_ids or named_ids == {str(identified[0][1]["id"])}
    ):
        return identified[0]
    if named_ids or identified:
        return None
    opaque = [
        entry
        for entry in candidates
        if any(entry[1].get(key) for key in ("encrypted_content", "signature", "data"))
    ]
    if len(opaque) == 1:
        return opaque[0]
    return None
