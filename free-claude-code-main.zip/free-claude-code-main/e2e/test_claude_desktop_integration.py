import json
from pathlib import Path

import pytest
from playwright.sync_api import Page, Route, expect

from free_claude_code.harnesses import claude_desktop_integration as desktop
from tests.wire_payload import object_payload, response_object


@pytest.mark.parametrize("status_failure", ["none", "read", "startup"])
def test_real_disconnect_failure_keeps_retry_after_reload(
    page: Page,
    admin_base_url: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    status_failure: str,
):
    profile = tmp_path / "Claude-3p/configLibrary" / f"{desktop.FCC_ID}.json"
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openClaudeDesktopIntegration")
    expect(opener).to_have_text("Connect")
    opener.click()
    dialog = page.locator("#claudeDesktopIntegrationDialog")
    dialog.get_by_role("button", name="Connect", exact=True).click()
    expect(opener).to_have_text("Disconnect")
    unlink = Path.unlink

    def fail(path: Path, missing_ok: bool = False):
        if path == profile:
            raise PermissionError("test")
        return unlink(path, missing_ok=missing_ok)

    with monkeypatch.context() as patch:
        patch.setattr(Path, "unlink", fail)
        opener.click()
        endpoint = "**/admin/api/integrations/claude-desktop"
        if status_failure == "read":
            page.route(
                endpoint,
                lambda route: route.fulfill(
                    status=503, json={"detail": "Status unavailable"}
                ),
            )
        elif status_failure == "startup":
            marker = tmp_path / ".fcc/claude-desktop-disconnect.json"
            failed = {"state": "failed", "message": "Startup check failed"}

            def failed_update(route: Route):
                result = route.fetch()
                body = response_object(result)
                if marker.exists():
                    body["connected"] = None
                    body["update"] = failed
                route.fulfill(response=result, json=body)

            def failed_startup(route: Route):
                result = route.fetch()
                body = response_object(result)
                if marker.exists():
                    object_payload(object_payload(body["startup"])["integrations"])[
                        "claude-desktop"
                    ] = failed
                route.fulfill(response=result, json=body)

            page.route(endpoint, failed_update)
            page.route("**/admin/api/status", failed_startup)
        dialog.get_by_role("button", name="Disconnect", exact=True).click()
        expect(
            dialog.get_by_role(
                "button",
                name="Disconnect" if status_failure == "read" else "Retry disconnect",
                exact=True,
            )
        ).to_be_enabled()
        expect(dialog.get_by_role("alert")).to_be_visible()
        assert profile.exists()
        if status_failure == "read":
            page.unroute(endpoint)
        page.reload()
        expect(opener).to_have_text("Retry disconnect")
        expect(opener).to_be_enabled()
    opener.click()
    dialog.get_by_role("button", name="Retry disconnect", exact=True).click()
    expect(dialog).not_to_be_visible()
    expect(opener).to_have_text("Connect")
    assert not profile.exists()
    assert not (tmp_path / ".fcc/claude-desktop-disconnect.json").exists()


def test_desktop_connect_disconnect_and_retry(
    page: Page, admin_base_url: str, tmp_path: Path
):
    page.set_viewport_size({"width": 1440, "height": 1000})
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openClaudeDesktopIntegration")
    expect(opener).to_have_text("Connect")
    expect(opener).to_be_enabled()
    dialog = page.locator("#claudeDesktopIntegrationDialog")
    profile = tmp_path / "Claude-3p/configLibrary" / f"{desktop.FCC_ID}.json"
    for dismissal in ("close", "escape", "outside"):
        opener.click()
        expect(dialog).to_be_visible()
        expect(dialog.locator("#claudeDesktopIntegrationFiles")).to_contain_text(
            str(profile.resolve())
        )
        dialog.locator("p").first.click()
        expect(dialog).to_be_visible()
        if dismissal == "close":
            dialog.get_by_role("button", name="Close", exact=True).click()
        elif dismissal == "escape":
            page.keyboard.press("Escape")
        else:
            page.mouse.click(1, 1)
        expect(dialog).not_to_be_visible()
        expect(opener).to_be_focused()
    assert not profile.exists()
    opener.click()
    page.screenshot(path=str(tmp_path / "claude-desktop-connect.png"))
    action = dialog.get_by_role("button", name="Connect", exact=True)
    action.click()
    expect(dialog).not_to_be_visible()
    expect(opener).to_have_text("Disconnect")
    expect(opener).to_have_css("color", "rgb(239, 68, 68)")
    assert json.loads(profile.read_text())["inferenceProvider"] == "gateway"
    page.reload()
    expect(opener).to_have_text("Disconnect")
    page.screenshot(path=str(tmp_path / "claude-desktop-connected.png"))
    opener.click()
    endpoint = "**/admin/api/integrations/claude-desktop/disconnect"
    page.route(
        endpoint,
        lambda route: route.fulfill(
            status=503, json={"detail": "File is busy; retry."}
        ),
    )
    dialog.get_by_role("button", name="Disconnect", exact=True).click()
    expect(dialog).to_be_visible()
    expect(dialog.get_by_role("alert")).to_contain_text("retry")
    expect(dialog.get_by_role("button", name="Disconnect", exact=True)).to_be_enabled()
    page.unroute(endpoint)
    dialog.get_by_role("button", name="Disconnect", exact=True).click()
    expect(dialog).not_to_be_visible()
    expect(opener).to_have_text("Connect")
    assert not profile.exists()
    assert (
        json.loads((tmp_path / "Claude-3p/claude_desktop_config.json").read_text())[
            "deploymentMode"
        ]
        == "1p"
    )
    assert not (tmp_path / "vscode/settings.json").exists()
    expect(page.locator("#dirtyState")).to_have_text("No changes")
