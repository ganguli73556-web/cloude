"""The DSH Desktop card uses real isolated native configuration files."""

import asyncio
import json
import threading
from pathlib import Path
from typing import Literal

import pytest
from playwright.sync_api import Page, expect
from ruamel.yaml import YAML

from free_claude_code.core.json_types import JsonObject
from free_claude_code.runtime.integration_service import IntegrationService


def install(tmp_path: Path):
    home = tmp_path / ".dsh"
    profile = home / "profiles/desktop"
    profile.mkdir(parents=True, exist_ok=True)
    (profile / "package.json").write_text(
        json.dumps(
            {
                "dsh": {
                    "profile": {
                        "bundles": ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app"]
                    }
                },
            }
        )
    )
    return home


def test_connect_disconnect_preserves_native_settings(
    page: Page, admin_base_url: str, tmp_path: Path
):
    home = install(tmp_path)
    patch = home / "profiles/desktop/cordis.patch.yml"
    patch.write_text("- id: unrelated\n  config: {keep: unchanged}\n")
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openDshDesktopIntegration")
    expect(opener).to_have_text("Connect")
    opener.click()
    dialog = page.locator("#dshDesktopIntegrationDialog")
    expect(dialog).to_be_visible()
    expect(dialog.locator("#dshDesktopIntegrationFiles")).to_contain_text(
        str(patch.resolve())
    )
    dialog.get_by_role("button", name="Connect", exact=True).click()
    expect(dialog).not_to_be_visible()
    expect(opener).to_have_text("Disconnect")
    expect(opener).to_have_css("color", "rgb(239, 68, 68)")
    page.screenshot(path=str(tmp_path / "dsh-integrations.png"), full_page=True)
    assert "free-claude-code" in patch.read_text()
    page.reload()
    expect(opener).to_have_text("Disconnect")
    opener.click()
    expect(dialog.locator("#dshDesktopIntegrationDescription")).to_contain_text(
        "Existing"
    )
    dialog.get_by_role("button", name="Disconnect", exact=True).click()
    expect(opener).to_have_text("Connect")
    assert "free-claude-code" not in patch.read_text()
    rows: list[JsonObject] = YAML().load(patch.read_text())
    assert rows[0] == {"id": "unrelated", "config": {"keep": "unchanged"}}
    expect(page.locator("#dirtyState")).to_have_text("No changes")


def test_setup_error_and_retry_remain_in_dialog(
    page: Page, admin_base_url: str, tmp_path: Path
):
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openDshDesktopIntegration")
    expect(opener).to_have_text("Connect")
    opener.click()
    dialog = page.locator("#dshDesktopIntegrationDialog")
    dialog.get_by_role("button", name="Connect", exact=True).click()
    expect(dialog.get_by_role("alert")).to_contain_text("open")
    expect(dialog.get_by_role("button", name="Connect", exact=True)).to_be_enabled()
    install(tmp_path)
    dialog.get_by_role("button", name="Connect", exact=True).click()
    expect(dialog).not_to_be_visible()
    expect(opener).to_have_text("Disconnect")


def test_superseded_connect_notice_matches_real_disconnect(
    page: Page, admin_base_url: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    from contextlib import asynccontextmanager

    from free_claude_code.runtime.integration_service import IntegrationService

    home = install(tmp_path)
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openDshDesktopIntegration")
    expect(opener).to_have_text("Connect")
    entered, release = threading.Event(), threading.Event()
    original = IntegrationService._dsh_desktop

    async def held(
        service: IntegrationService,
        action: Literal["connect", "disconnect", "refresh", "status"],
    ):
        if action == "connect":
            write = service._dsh_update.access.write
            first = True

            @asynccontextmanager
            async def held_write():
                nonlocal first
                if first:
                    first = False
                    entered.set()
                    assert await asyncio.to_thread(release.wait, 10)
                async with write():
                    yield

            monkeypatch.setattr(service._dsh_update.access, "write", held_write)
        return await original(service, action)

    monkeypatch.setattr(IntegrationService, "_dsh_desktop", held)
    endpoint = admin_base_url + "/admin/api/integrations/dsh-desktop"
    try:
        opener.click()
        page.locator("#confirmDshDesktopIntegration").click()
        assert entered.wait(5)
        response = page.request.post(endpoint + "/disconnect")
        assert response.ok
        assert not response.json()["connected"]
    finally:
        release.set()
    expect(page.locator("#dshDesktopIntegrationDialog")).not_to_be_visible()
    expect(opener).to_have_text("Connect")
    notice = page.locator("#dshDesktopIntegrationMessage")
    expect(notice).to_contain_text("disconnected")
    expect(notice).not_to_contain_text("Connected.")
    assert not page.request.get(endpoint).json()["connected"]
    assert not (home / "profiles/desktop/cordis.patch.yml").exists()


def test_changed_fcc_setting_shows_connect_and_is_replaced(
    page: Page, admin_base_url: str, tmp_path: Path
):
    home = install(tmp_path)
    page.goto(admin_base_url + "/admin/integrations")
    opener = page.locator("#openDshDesktopIntegration")
    expect(opener).to_have_text("Connect")
    opener.click()
    page.locator("#confirmDshDesktopIntegration").click()
    expect(opener).to_have_text("Disconnect")
    credentials = home / ".credentials.yaml"
    credentials.write_text("version: 1\nrefs: {FCC_DSH_DESKTOP_API_KEY: edited}\n")
    page.reload()
    expect(opener).to_have_text("Connect")
    opener.click()
    page.locator("#confirmDshDesktopIntegration").click()
    expect(opener).to_have_text("Disconnect")
    assert "edited" not in credentials.read_text()
